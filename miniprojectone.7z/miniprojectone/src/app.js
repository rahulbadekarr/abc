require("dotenv").config();
console.log(process.env); // remove this after you've confirmed it working

const express = require("express");
const app = express();
const port = process.env.PORT || 3000;
require("./db/connection");
const path = require("path");
const hbs = require("hbs");
const Register = require("./model/structureregister");
const async = require("hbs/lib/async");
const Registerdata = require("./model/structureregister");
const requests = require("requests");
const bcryptjs = require("bcryptjs");
var cookieParser = require("cookie-parser");
const auth = require("./middleware/auth");

staticpath = path.join(__dirname, "../public/"); //to get the path

const templatepath = path.join(__dirname, "../templates/views");
const partialpath = path.join(__dirname, "../templates/partials");

app.use(express.static(staticpath));
app.use(cookieParser());

app.set("view engine", "hbs");
app.set("views", templatepath);

hbs.registerPartials(partialpath);

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

console.log(process.env.SECKEY);

app.get("/", (req, res) => {
  // res.send(`Welcome to home @Weathercondition! `)
  res.render("index.hbs");
});
// app.get("/register", (req, res) => {
//   // res.send(`Welcome to home @Weathercondition! `)
//   res.render("register.hbs");
// });

app.post("/register", async (req, res) => {
  try {
    const passwd = req.body.password;
    const cpasswd = req.body.cpassword;
    if (passwd === cpasswd) {
      const registerationdata = new Registerdata({
        fname: req.body.fname,
        lname: req.body.lname,
        email: req.body.email,
        contact: req.body.contact,
        age: req.body.age,
        gender: req.body.gender,
        password: passwd,
        cpassword: cpasswd,
      });

      console.log("generating token!!!");
      const token = await registerationdata.generatejwtToken();
      console.log("token generated", token);

      //save Cookie
      res.cookie("jwt", token, {
        expires: new Date(Date.now() + 150000),
        httpOnly: true,
      });
      //Saving the register form ui data to database
      const registered = await registerationdata.save();

      res.status(201).render("login");
    } else {
      res.send("Please fill all the details correctly");
    }
    // console.log(req.body.fname)
    // res.send(req.body)
    // res.render("register.hbs")
  } catch (err) {
    console.log(err);
  }
});

app.get("/login", (req, res) => {
  // res.send(`Welcome to home @Weathercondition! `)
  res.render("login.hbs");
});

app.post("/login", async (req, res) => {
  try {
    const email = req.body.email;
    const password = req.body.password;

    const useremail = await Registerdata.findOne({ email: email });
    console.log(useremail);

    const passwordMatch = await bcryptjs.compare(password, useremail.password);

    //Middleware of token
    const logintoken = await useremail.generatejwtToken();
    console.log("Login token", logintoken);
    // if(useremail.password===password){

    //cookie method is used to store the token on cookie on your browser
    res.cookie("jwt", logintoken, {
      expires: new Date(Date.now() + 150000),
      httpOnly: true,
      // secure:true
    });

    if (passwordMatch) {
      res.render("register");
    } else {
      // res.status(404).send(useremail)
      res.send("Invalid Credentials!!");
    }
  } catch (err) {
    console.log(err);
  }
});

// weather

app.get("/register",auth, async (req, res) => {
  try {
    requests(
      `http://api.openweathermap.org/data/2.5/weather?q=${req.query.name}&appid=606488a5615ce23352393844ca740e65`
    ).on("data", (chunk) => {
      const objdata = JSON.parse(chunk);
      const arrdata = [objdata];
console.log(arrdata);
// console.log(arrdata[0].coord.lon);
const longitude=arrdata[0].coord.lon;
const humidity=arrdata[0].main.humidity;

      const celsius = arrdata[0].main.temp - 273;
      const a = Math.ceil(celsius);
      const b = a.toString();
      console.log(b);
      console.log(`City : ${arrdata[0].name} Temperature is ${a}`);
      // res.status(200).sendStatus(a);
      // res.write(a)

      // res.sendStatus(a);

      // res.write(`City : ${arrdata[0].name} Temperature is ${b}`);

      // res.send();
      //  res.render("abc.hbs");
      res.write(`City : ${arrdata[0].name} Temperature is ${b} `);
      // console.log(arrdata[0].coord.lon);
      res.write(` Longitude is ${longitude}`);
      res.write(` Humidity is ${humidity}`);
      // res.render("abc.hbs");
      res.send();
    });
  } catch (err) {
    console.log(err);
  }
});

app.get("/abc", auth, (req, res) => {
  // res.send(`Welcome to home @Weathercondition! `)
  // console.log("cookie",req.cookies.jwt)
  res.render("abc.hbs");
});

app.get("/logout", auth, async (req, res) => {
  try {
    console.log(req.token);

    // For single user logout
    // req.loggeduserData.tokens = req.loggeduserData.tokens.filter(
    //   (currenttokens) => {
    //     return currenttokens.token != req.token;
    //   }
    // );
    //  console.log(req.user);
    //  console.log(req.token);

    // for multiple users which are logged in from multiple devices can be logged out in one go
    req.loggeduserData.tokens=[]


    res.clearCookie("jwt");
    console.log("logout successfully");

    await req.loggeduserData.save();
    // console.log("logout1 successfully");
    res.render("login.hbs");
    // res.send("hi logout")
  } catch (error) {
    res.status(500).send(error);
  }
});

app.listen(port, () => {
  console.log(`Listening @ ${port}`);
});
