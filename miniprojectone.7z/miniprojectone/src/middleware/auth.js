const jwt=require("jsonwebtoken");
const Register = require("../model/structureregister");

const auth=async (req,res,next)=>{

    try{
        const token=req.cookies.jwt;
        
        const verifyuser=jwt.verify(token,process.env.SECKEY)
        console.log("auth",verifyuser);
        
        const loggeduserData=await Register.findOne({_id:verifyuser._id});
        console.log(loggeduserData);

        req.token=token;  //by this iam sending the token and user data in /logout path/function
        req.loggeduserData=loggeduserData;

        next()

    }catch(error){
        console.log("Inside auth Error: ",error);
        res.status(401).send(error.message);
        // res.status(401).send(error);
    }
}

module.exports=auth;