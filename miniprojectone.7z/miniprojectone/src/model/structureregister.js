// Schema creation

const async = require("hbs/lib/async");
const mongoose = require("mongoose");
const bcryptjs = require("bcryptjs");
const jwt = require("jsonwebtoken");

const employeeSchema = new mongoose.Schema({
  fname: { type: String, required: true },
  lname: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  contact: { type: Number, required: true, unique: true },
  age: { type: Number, required: true },
  gender: { type: String, required: true },
  password: { type: String, required: true },
  cpassword: { type: String, required: true },
  tokens:[{token:{
                    type: String, required: true
                 }
         }]


});

//Generating token using jsonwebtoken package
employeeSchema.methods.generatejwtToken = async function () {
  try {
    const jwttoken = jwt.sign({ _id: this._id.toString() },process.env.SECKEY);
    this.tokens= this.tokens.concat({token:jwttoken});
    
    // console.log(jwttoken);
    await this.save();

    return jwttoken;
  } catch (err) {
    console.log(err);
  }
};

//password is hashed: After fetching the data and before saving to the database we need to convert into hash(Middleware)
employeeSchema.pre("save", async function (next) {
  if (this.isModified("password")) {
    //   console.log(`${this.password}`);
    this.password = await bcryptjs.hash(this.password, 10);
    //   console.log(`${this.password}`);
    this.cpassword = this.password;
  }
  next();
});

//Collection name ,Registerdata is name of class now/instance
const Registerdata = new mongoose.model("Register", employeeSchema);
module.exports = Registerdata;
