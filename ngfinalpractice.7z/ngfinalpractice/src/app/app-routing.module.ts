import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AttridirComponent } from './components/attridir/attridir.component';

import { ChildComponent } from './components/parent/child/child.component';
import { ParentComponent } from './components/parent/parent.component';
import { PipesComponent } from './components/pipes/pipes.component';
import { ReactiveformComponent } from './components/reactiveform/reactiveform.component';
import { StructdirComponent } from './components/structdir/structdir.component';
import { TemplateformComponent } from './components/templateform/templateform.component';
import { CanactivateGuard } from './components/guards/canactivate.guard';
import { CanactivatechildGuard } from './components/guards/canactivatechild.guard';
import { TdfComponent } from './components/tdf/tdf.component';
import { RfComponent } from './components/rf/rf.component';
import { FromeventComponent } from './components/rxjs/fromevent/fromevent.component';
import { SubjectmainComponent } from './components/subject/subjectmain/subjectmain.component';
import { SerwithoutinjComponent } from './components/serwithoutinj/serwithoutinj.component';
const routes: Routes = [
  {
    path: 'parent',
    component: ParentComponent,canActivate:[CanactivateGuard],
    children: [{ path: 'child', component: ChildComponent }],
    canActivateChild:[CanactivatechildGuard],
  },
  { path: 'pipes', component: PipesComponent },
  { path: 'attribute', component: AttridirComponent },
  { path: 'structure', component: StructdirComponent },
  { path: 'reactive', component: ReactiveformComponent },
  { path: 'template', component: TemplateformComponent },
  { path: 'tdf', component: TdfComponent },
  { path: 'rf', component: RfComponent },
  { path: 'fromevent', component: FromeventComponent },
  { path: 'subject', component: SubjectmainComponent },
  { path: 'serwithout', component: SerwithoutinjComponent },
  {path:'lazy',loadChildren:()=>import('./components/lazily/lazy/lazy.module').then(m=>m.LazyModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
