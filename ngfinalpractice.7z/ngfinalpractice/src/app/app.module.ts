import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ParentComponent } from './components/parent/parent.component';
import { ChildComponent } from './components/parent/child/child.component';
import { PipesComponent } from './components/pipes/pipes.component';
import { CustompipePipe } from './components/pipes/custompipe.pipe';
import { AttridirComponent } from './components/attridir/attridir.component';
import { StructdirComponent } from './components/structdir/structdir.component';
import { ReactiveformComponent } from './components/reactiveform/reactiveform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule}from '@angular/common/http';
import { TemplateformComponent } from './components/templateform/templateform.component'
import { httpinter } from './components/http/httpint';
import { CommonModule } from '@angular/common';
import { TdfComponent } from './components/tdf/tdf.component';
import { RfComponent } from './components/rf/rf.component';
import { FromeventComponent } from './components/rxjs/fromevent/fromevent.component';
import { IntervalComponent } from './components/rxjs/interval/interval.component';
import { PluckComponent } from './components/rxjs/pluck/pluck.component';
import { MergeallComponent } from './components/rxjs/mergeall/mergeall.component';
import { SubjectoneComponent } from './components/subject/subjectone/subjectone.component';
import { SubjecttwoComponent } from './components/subject/subjecttwo/subjecttwo.component';
import { SubjectmainComponent } from './components/subject/subjectmain/subjectmain.component';
import { SerwithoutinjComponent } from './components/serwithoutinj/serwithoutinj.component';
@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildComponent,
    PipesComponent,
    CustompipePipe,
    AttridirComponent,
    StructdirComponent,
    ReactiveformComponent,
    TemplateformComponent,
    TdfComponent,
    RfComponent,
    FromeventComponent,
    IntervalComponent,
    PluckComponent,
    MergeallComponent,
    SubjectoneComponent,
    SubjecttwoComponent,
    SubjectmainComponent,
    SerwithoutinjComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule

  ],
  providers: [httpinter],
  bootstrap: [AppComponent]
})
export class AppModule { }
