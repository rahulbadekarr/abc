import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structdir',
  templateUrl: './structdir.component.html',
  styleUrls: ['./structdir.component.css']
})
export class StructdirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  present=false;
  color='green';

  emp=[
    {name:'raj',roll:1},
    {name:'raja',roll:12},
    {name:'rajes',roll:13},
  ]

}
