import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StructdirComponent } from './structdir.component';

describe('StructdirComponent', () => {
  let component: StructdirComponent;
  let fixture: ComponentFixture<StructdirComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StructdirComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StructdirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
