import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerwithoutinjComponent } from './serwithoutinj.component';

describe('SerwithoutinjComponent', () => {
  let component: SerwithoutinjComponent;
  let fixture: ComponentFixture<SerwithoutinjComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SerwithoutinjComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SerwithoutinjComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
