import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Servwithout } from './servic';

@Component({
  selector: 'app-serwithoutinj',
  templateUrl: './serwithoutinj.component.html',
  styleUrls: ['./serwithoutinj.component.css']
})
export class SerwithoutinjComponent implements OnInit {

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }

  send(){
    const servic=new Servwithout(this.http);
    servic.onFetch().subscribe((data)=>{
      console.log(data)
    })
  }
}
