import { HttpClient } from "@angular/common/http";

export class Servwithout{


  constructor(private http:HttpClient){

  }
  baseUrl="http://localhost:3000/employee";

  onFetch(){
    return this.http.get(this.baseUrl)
  }
}
