import { Component, OnInit } from '@angular/core';
import { UtilityserviceService } from '../utilityservice.service';

@Component({
  selector: 'app-subjecttwo',
  templateUrl: './subjecttwo.component.html',
  styleUrls: ['./subjecttwo.component.css']
})
export class SubjecttwoComponent implements OnInit {

  fname:string=''
  constructor(private util:UtilityserviceService) {

    this.util.fname.subscribe((value)=>{
      this.fname=value;
    })
   }

  ngOnInit(): void {
  }
  send(data:string){
    this.util.fname.next(data)
      }
}
