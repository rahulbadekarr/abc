import { Component, OnInit } from '@angular/core';
import { UtilityserviceService } from '../utilityservice.service';

@Component({
  selector: 'app-subjectone',
  templateUrl: './subjectone.component.html',
  styleUrls: ['./subjectone.component.css']
})
export class SubjectoneComponent implements OnInit {

  fname:string=''
  constructor(private util:UtilityserviceService) {

    this.util.fname.subscribe((value)=>{
      this.fname=value;
    })
   }

  ngOnInit(): void {
  }

  send(data:string){
this.util.fname.next(data)
  }
}
