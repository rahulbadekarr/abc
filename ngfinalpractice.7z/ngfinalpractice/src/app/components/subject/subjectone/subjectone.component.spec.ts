import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubjectoneComponent } from './subjectone.component';

describe('SubjectoneComponent', () => {
  let component: SubjectoneComponent;
  let fixture: ComponentFixture<SubjectoneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubjectoneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubjectoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
