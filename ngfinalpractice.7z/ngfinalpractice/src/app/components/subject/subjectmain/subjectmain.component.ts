import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subjectmain',
  templateUrl: './subjectmain.component.html',
  styleUrls: ['./subjectmain.component.css']
})
export class SubjectmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
