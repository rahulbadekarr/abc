import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ApidbService } from './apidb.service';

@Component({
  selector: 'app-reactiveform',
  templateUrl: './reactiveform.component.html',
  styleUrls: ['./reactiveform.component.css'],
})
export class ReactiveformComponent implements OnInit {
  constructor(private fb: FormBuilder,private apidb:ApidbService) {}
  form: any ;
  ngOnInit(): void {
    this.form=this.fb.group({
      fname: ['', Validators.required],
      lname: ['', Validators.required],
    });
  }

  submit(d:any){
    this.apidb.onPost(d.value).subscribe((d)=>console.log(d))
    // console.log(this.form)
  }

  get(){
    this.apidb.onFetch().subscribe((d)=>console.log(d))
  }
}
