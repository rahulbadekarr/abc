import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApidbService {

baseUrl="http://localhost:3000/employee"
  constructor(private http:HttpClient) { }

  onFetch(){
    return this.http.get(this.baseUrl);
  }

  onPost(data:any){
    return this.http.post(this.baseUrl,data)
    .pipe(catchError(this.errorHandler))
  }

  errorHandler(error:HttpErrorResponse){
return throwError(error)
  }

}
