import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class ParentComponent implements OnInit {

  constructor() { }

  fname:string='rahul';
  last:string='';

  ngOnInit(): void {
  }

  received(data:any){

    this.last=data;
    console.log(data)
  }

}
