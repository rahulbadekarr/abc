import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
})
export class ChildComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}

  @Input() name: any;
  @Output() lname = new EventEmitter();

  lastname = 'mono';

  send() {

    this.lname.emit(this.lastname);
    // console.log("inside send",this.lastname)
  }
}
