import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe',
  pure:false
})
export class CustompipePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    console.log("Getting triggered n times")
    return value.join();
  }

}
