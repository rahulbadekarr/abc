import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  myname:string='rahulmono';
  dob=new Date();
  amount=5000;

  data=['raj']

  send(data:any){
    console.log(data);
    this.data.push(data);

  }

}
