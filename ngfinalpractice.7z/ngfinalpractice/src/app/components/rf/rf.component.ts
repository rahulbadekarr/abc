import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ApidbService } from '../reactiveform/apidb.service';
import { PasswordValidator } from './shared/password.validator';

@Component({
  selector: 'app-rf',
  templateUrl: './rf.component.html',
  styleUrls: ['./rf.component.css'],
})
export class RfComponent implements OnInit {
  registrationForm: FormGroup;
  get userName() {
    return this.registrationForm.get('username');
  }
  constructor(private fb: FormBuilder,private apidb:ApidbService) {}

  // registrationForm = new FormGroup({
  //   username: new FormControl('rahul'),
  //   password: new FormControl(''),
  //   cpassword: new FormControl(''),
  //   address: new FormGroup({
  //     city: new FormControl(''),
  //     state: new FormControl(''),
  //     pin: new FormControl(''),
  //   }),
  // });


  ngOnInit(): void {
    this.registrationForm = this.fb.group(
      {
        username: ['rmono', [Validators.required, Validators.minLength(3)]],
        email: [''],
        subscribe: [false],
        password: [''],
        cpassword: [''],
        address: this.fb.group({
          city: [''],
          state: [''],
          pin: [''],
        }),
      },
      { validator: PasswordValidator }
    );

    this.registrationForm
      .get('subscribe')
      .valueChanges.subscribe((checkedValue) => {
        const email = this.registrationForm.get('email');
        console.log("Email",email)
        // console.log(this.registrationForm.get('username'))
        if (checkedValue) {
          email.setValidators(Validators.required);
        } else {
          email.clearValidators();
        }
        email.updateValueAndValidity();
      });
  }

  send() {

    this.apidb.onPost(this.registrationForm.value).subscribe({
      next:(data)=>console.log(data),
      error:(err)=>console.log(err),
      complete:()=>console.log("completed!!")
    })
    console.log(this.registrationForm.value)
  }

  loaddata() {
    this.registrationForm.patchValue({
      username: 'rahulmono',
      password: '123',
      cpassword: '123',
    });
  }
}
