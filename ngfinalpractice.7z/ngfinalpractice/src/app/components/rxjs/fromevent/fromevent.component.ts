import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { of } from 'rxjs';
import { fromEvent } from 'rxjs/internal/observable/fromEvent';

@Component({
  selector: 'app-fromevent',
  templateUrl: './fromevent.component.html',
  styleUrls: ['./fromevent.component.css']
})
export class FromeventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @ViewChild('frommyevent')
  my:ElementRef;

  ngAfterViewInit(){
    fromEvent(this.my.nativeElement,'click').subscribe((d)=>{console.log(d)}) //mouseover

    // of(1,2,3)
    of([1,2,3,4,5],[2,4]).subscribe({
      next:(data)=>console.log('Index',data),
      error:(error)=>console.log(error)
    })
  }



}
