import { Component, OnInit } from '@angular/core';
import { map, Subscription, timer } from 'rxjs';
import { interval } from 'rxjs/internal/observable/interval';

@Component({
  selector: 'app-interval',
  templateUrl: './interval.component.html',
  styleUrls: ['./interval.component.css']
})
export class IntervalComponent implements OnInit {

  constructor() { }
  unsub:Subscription

  ngOnInit(): void {

    const a=interval(1000);
    // const a=timer(7000,1000);
    this.unsub=a.pipe(map(x=>x*10)).subscribe((d)=>{
    // a.subscribe((d)=>{

      console.log(d);
      if(d>50){

        this.unsub.unsubscribe();
      }
    })

  }

}
