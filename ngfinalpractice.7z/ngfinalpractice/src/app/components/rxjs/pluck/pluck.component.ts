import { Component, OnInit } from '@angular/core';
import { from, map, pluck, take, toArray } from 'rxjs';

@Component({
  selector: 'app-pluck',
  templateUrl: './pluck.component.html',
  styleUrls: ['./pluck.component.css'],
})
export class PluckComponent implements OnInit {
  constructor() {}

  emp = [
    {
      name: 'rahul',
      age: 22,
    },
    {
      name: 'sagar',
      age: 23,
    },
    {
      name: 'sumit',
      age: 24,
    }

  ];
  ngOnInit(): void {

    from(this.emp).pipe(map(x=>x.age),take(2),toArray()).subscribe((d)=>console.log(d));
    from(this.emp).pipe(pluck('name'),take(2),toArray()).subscribe((d)=>console.log(d));
  }


}
