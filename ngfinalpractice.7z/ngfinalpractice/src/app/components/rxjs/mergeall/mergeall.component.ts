import { Component, OnInit } from '@angular/core';
import { from, map, mergeAll, toArray } from 'rxjs';

@Component({
  selector: 'app-mergeall',
  templateUrl: './mergeall.component.html',
  styleUrls: ['./mergeall.component.css']
})
export class MergeallComponent implements OnInit {

  emp=[
    {name:'raj',skills:['angular','react','vue']},
    {name:'suraj',skills:['angular','react','vue']},
    {name:'araj',skills:['angular','react','vue']},
  ]

  constructor() { }

  ngOnInit(): void {

    from(this.emp).pipe(map(x=>x.skills),mergeAll(),toArray()).subscribe((d)=>console.log(d));
  }

}
