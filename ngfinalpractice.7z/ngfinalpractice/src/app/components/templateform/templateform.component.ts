import { Component, OnInit } from '@angular/core';
import { ApidbService } from '../reactiveform/apidb.service';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.css']
})
export class TemplateformComponent implements OnInit {

  constructor(private apidb:ApidbService) { }

  ngOnInit(): void {
  }

  send(d:any){
this.apidb.onPost(d).subscribe((d)=>{console.log(d)})
  }

}
