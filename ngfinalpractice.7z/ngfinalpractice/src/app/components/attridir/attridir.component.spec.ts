import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttridirComponent } from './attridir.component';

describe('AttridirComponent', () => {
  let component: AttridirComponent;
  let fixture: ComponentFixture<AttridirComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttridirComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AttridirComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
