import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attridir',
  templateUrl: './attridir.component.html',
  styleUrls: ['./attridir.component.css']
})
export class AttridirComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  present:boolean=true;
  col={'color':'green'}

}
