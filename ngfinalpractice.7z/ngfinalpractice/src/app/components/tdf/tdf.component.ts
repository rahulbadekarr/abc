import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ApidbService } from '../reactiveform/apidb.service';
import { User } from './user';

@Component({
  selector: 'app-tdf',
  templateUrl: './tdf.component.html',
  styleUrls: ['./tdf.component.css']
})
export class TdfComponent implements OnInit {
  errorMsg=''
  submitted=true;
  topics=['Angular','React','Vue','None','Ving','angi','vick'];
  userModel=new User('','rahul@gmail.com',9789998981,'','morning',true)
  constructor(private apidb:ApidbService) { }

  ngOnInit(): void {
  }

  send(){
    this.submitted=false;
     this.apidb.onPost(this.userModel).subscribe({

      next:(data)=>console.log(data),
      // error:(err)=>console.log(err),
      // first way of error handling
      error:(err)=>this.errorMsg=err.statusText,
      complete:()=>console.log("completed")
    }

     )
    // console.log(this.userModel)
  }


}
