import { HTTP_INTERCEPTORS } from "@angular/common/http";
import { FirstInter } from "./first";
import { Second } from "./second";

export const httpinter=[

  {provide:HTTP_INTERCEPTORS,useClass:FirstInter,multi:true},
  {provide:HTTP_INTERCEPTORS,useClass:Second,multi:true},
]
