import { TestBed } from '@angular/core/testing';

import { LazilyResolver } from './lazily.resolver';

describe('LazilyResolver', () => {
  let resolver: LazilyResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(LazilyResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});
